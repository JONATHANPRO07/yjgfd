gdjs.l2Code = {};

gdjs.l2Code.conditionTrue_0 = {val:false};
gdjs.l2Code.condition0IsTrue_0 = {val:false};


gdjs.l2Code.eventsList0xb24c0 = function(runtimeScene) {

}; //End of gdjs.l2Code.eventsList0xb24c0


gdjs.l2Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.l2Code.eventsList0xb24c0(runtimeScene);
return;

}
gdjs['l2Code'] = gdjs.l2Code;
