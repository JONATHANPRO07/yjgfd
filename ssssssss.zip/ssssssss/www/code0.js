gdjs.NewSceneCode = {};
gdjs.NewSceneCode.GDNewObjectObjects1= [];
gdjs.NewSceneCode.GDNewObjectObjects2= [];
gdjs.NewSceneCode.GDNewObject2Objects1= [];
gdjs.NewSceneCode.GDNewObject2Objects2= [];
gdjs.NewSceneCode.GDgObjects1= [];
gdjs.NewSceneCode.GDgObjects2= [];
gdjs.NewSceneCode.GDNewObject3Objects1= [];
gdjs.NewSceneCode.GDNewObject3Objects2= [];
gdjs.NewSceneCode.GDjumpObjects1= [];
gdjs.NewSceneCode.GDjumpObjects2= [];
gdjs.NewSceneCode.GDleftObjects1= [];
gdjs.NewSceneCode.GDleftObjects2= [];
gdjs.NewSceneCode.GDrightObjects1= [];
gdjs.NewSceneCode.GDrightObjects2= [];
gdjs.NewSceneCode.GDvObjects1= [];
gdjs.NewSceneCode.GDvObjects2= [];

gdjs.NewSceneCode.conditionTrue_0 = {val:false};
gdjs.NewSceneCode.condition0IsTrue_0 = {val:false};
gdjs.NewSceneCode.condition1IsTrue_0 = {val:false};


gdjs.NewSceneCode.eventsList0x6960ec = function(runtimeScene) {

{


{
gdjs.NewSceneCode.GDNewObject2Objects1.createFrom(runtimeScene.getObjects("NewObject2"));
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.NewSceneCode.GDNewObject2Objects1.length !== 0 ? gdjs.NewSceneCode.GDNewObject2Objects1[0] : null), true, "", 0);
}}

}


}; //End of gdjs.NewSceneCode.eventsList0x6960ec
gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDjumpObjects1Objects = Hashtable.newFrom({"jump": gdjs.NewSceneCode.GDjumpObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDrightObjects1Objects = Hashtable.newFrom({"right": gdjs.NewSceneCode.GDrightObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDleftObjects1Objects = Hashtable.newFrom({"left": gdjs.NewSceneCode.GDleftObjects1});gdjs.NewSceneCode.eventsList0xb24c0 = function(runtimeScene) {

{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "n");
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "l2");
}}

}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
gdjs.NewSceneCode.GDNewObject2Objects1.createFrom(runtimeScene.getObjects("NewObject2"));
{for(var i = 0, len = gdjs.NewSceneCode.GDNewObject2Objects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDNewObject2Objects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{


{
gdjs.NewSceneCode.GDNewObject2Objects1.createFrom(runtimeScene.getObjects("NewObject2"));
{for(var i = 0, len = gdjs.NewSceneCode.GDNewObject2Objects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDNewObject2Objects1[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


{


{

{ //Subevents
gdjs.NewSceneCode.eventsList0x6960ec(runtimeScene);} //End of subevents
}

}


{


{
{gdjs.adMob.loadBanner("ca-app-pub-4222375929579621/9886915611", "", true, true, true, false);
}}

}


{

gdjs.NewSceneCode.GDjumpObjects1.createFrom(runtimeScene.getObjects("jump"));

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDjumpObjects1Objects, runtimeScene, false, false);
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
gdjs.NewSceneCode.GDNewObject2Objects1.createFrom(runtimeScene.getObjects("NewObject2"));
{for(var i = 0, len = gdjs.NewSceneCode.GDNewObject2Objects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDNewObject2Objects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{

gdjs.NewSceneCode.GDrightObjects1.createFrom(runtimeScene.getObjects("right"));

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDrightObjects1Objects, runtimeScene, false, false);
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
gdjs.NewSceneCode.GDvObjects1.createFrom(runtimeScene.getObjects("v"));
{for(var i = 0, len = gdjs.NewSceneCode.GDvObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDvObjects1[i].returnVariable(gdjs.NewSceneCode.GDvObjects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}

}


{

gdjs.NewSceneCode.GDleftObjects1.createFrom(runtimeScene.getObjects("left"));

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDleftObjects1Objects, runtimeScene, false, false);
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
gdjs.NewSceneCode.GDvObjects1.createFrom(runtimeScene.getObjects("v"));
{for(var i = 0, len = gdjs.NewSceneCode.GDvObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDvObjects1[i].returnVariable(gdjs.NewSceneCode.GDvObjects1[i].getVariables().getFromIndex(0)).setNumber(0);
}
}}

}


{

gdjs.NewSceneCode.GDvObjects1.createFrom(runtimeScene.getObjects("v"));

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDvObjects1.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDvObjects1[i].getVariableNumber(gdjs.NewSceneCode.GDvObjects1[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDvObjects1[k] = gdjs.NewSceneCode.GDvObjects1[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDvObjects1.length = k;}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
{gdjs.deviceVibration.startVibration(3000);
}}

}


{

gdjs.NewSceneCode.GDvObjects1.createFrom(runtimeScene.getObjects("v"));

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDvObjects1.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDvObjects1[i].getVariableNumber(gdjs.NewSceneCode.GDvObjects1[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDvObjects1[k] = gdjs.NewSceneCode.GDvObjects1[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDvObjects1.length = k;}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "C:\\Users\\jonat\\Downloads\\service-bell_daniel_simion.mp3", false, 10, 1);
}}

}


}; //End of gdjs.NewSceneCode.eventsList0xb24c0


gdjs.NewSceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.NewSceneCode.GDNewObjectObjects1.length = 0;
gdjs.NewSceneCode.GDNewObjectObjects2.length = 0;
gdjs.NewSceneCode.GDNewObject2Objects1.length = 0;
gdjs.NewSceneCode.GDNewObject2Objects2.length = 0;
gdjs.NewSceneCode.GDgObjects1.length = 0;
gdjs.NewSceneCode.GDgObjects2.length = 0;
gdjs.NewSceneCode.GDNewObject3Objects1.length = 0;
gdjs.NewSceneCode.GDNewObject3Objects2.length = 0;
gdjs.NewSceneCode.GDjumpObjects1.length = 0;
gdjs.NewSceneCode.GDjumpObjects2.length = 0;
gdjs.NewSceneCode.GDleftObjects1.length = 0;
gdjs.NewSceneCode.GDleftObjects2.length = 0;
gdjs.NewSceneCode.GDrightObjects1.length = 0;
gdjs.NewSceneCode.GDrightObjects2.length = 0;
gdjs.NewSceneCode.GDvObjects1.length = 0;
gdjs.NewSceneCode.GDvObjects2.length = 0;

gdjs.NewSceneCode.eventsList0xb24c0(runtimeScene);
return;

}
gdjs['NewSceneCode'] = gdjs.NewSceneCode;
